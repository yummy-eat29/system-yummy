# system yummy — Android / SP300W

تم تجهيز نسخة المشروع لدمج طباعة SP300W عبر Wi‑Fi/TCP داخل Capacitor.

إعدادات الطابعة:
- SSID: Printer-AP_7694
- IP: 192.168.123.100
- Port: 9100
- Protocol: TCP / ESC-POS

المهم: مجلد `www` يحتوي برنامج POS الأصلي مع ربط زر الطباعة بالطابعة الأصلية عند تشغيله داخل Capacitor.

## بناء المشروع

1. ثبّت Node.js وAndroid Studio.
2. داخل مجلد المشروع:
   `npm install`
3. أنشئ مجلد Android الأساسي:
   `npx cap add android`
4. انسخ ملفات `android/app/src/main/...` من هذا المشروع إذا أعاد Capacitor إنشاء مجلد Android.
5. نفّذ:
   `npx cap sync android`
6. افتح مجلد `android` في Android Studio ثم Build > Build APK(s).

هذا التسليم لا يحتوي APK ثنائيًا جاهزًا؛ APK يحتاج بيئة Android/Gradle لبنائه.
