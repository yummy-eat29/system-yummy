/**
 * printer-bridge.js
 * -----------------
 * Drop this <script> in right before </body> in your existing index.html.
 * It does NOT touch any existing feature, database, or UI — it only adds
 * a small floating status dot and a global `printReceipt()` / `testPrintSP300W()`
 * function that your existing "Print" button can call.
 *
 * Requires the app to be running inside the Capacitor native shell
 * (window.Capacitor.Plugins.PrinterPlugin). If it's opened in a normal
 * browser tab (no Capacitor), printing is silently disabled and the status
 * dot shows "unavailable" instead of crashing anything.
 */
(function () {
  const hasNativePrinter =
    typeof window.Capacitor !== "undefined" &&
    window.Capacitor.Plugins &&
    window.Capacitor.Plugins.PrinterPlugin;

  const Printer = hasNativePrinter ? window.Capacitor.Plugins.PrinterPlugin : null;

  // ---------- Status indicator (small floating dot, non-intrusive) ----------
  const dot = document.createElement("div");
  dot.id = "printer-status-dot";
  dot.style.cssText =
    "position:fixed;bottom:12px;left:12px;z-index:99999;" +
    "width:14px;height:14px;border-radius:50%;background:#999;" +
    "box-shadow:0 0 4px rgba(0,0,0,.4);transition:background .3s;";
  dot.title = "حالة الطابعة";
  document.addEventListener("DOMContentLoaded", () => document.body.appendChild(dot));

  function setDot(status) {
    const colors = { connected: "#2ecc71", connecting: "#f1c40f", disconnected: "#e74c3c" };
    dot.style.background = colors[status] || "#999";
    dot.title =
      status === "connected"
        ? "🟢 الطابعة متصلة"
        : status === "connecting"
        ? "🟡 جارٍ الاتصال..."
        : "🔴 الطابعة غير متصلة";
  }

  if (Printer) {
    Printer.getStatus().then((r) => setDot(r.status));
    Printer.addListener("printerStatusChanged", (data) => setDot(data.status));
  } else {
    setDot("disconnected");
    console.warn(
      "[printer-bridge] PrinterPlugin غير متاح — يجب تشغيل التطبيق داخل غلاف Capacitor الأندرويد وليس متصفح عادي."
    );
  }

  // ---------- Public API used by your existing "Print" button ----------

  /**
   * receipt = {
   *   lines: [ { text: "مطعم يمي", align: "center", bold: true }, ... ],
   *   qrText: "optional-order-id-or-url"
   * }
   * align can be "right" (default, best for Arabic), "left", or "center".
   */
  window.printReceipt = function (receipt) {
    if (!Printer) {
      alert("الطباعة غير متاحة — التطبيق يعمل كموقع وليس كتطبيق أندرويد.");
      return Promise.resolve(false);
    }
    return Printer.printReceipt(receipt);
  };

  window.testPrintSP300W = function () {
    if (!Printer) {
      alert("الطباعة غير متاحة — التطبيق يعمل كموقع وليس كتطبيق أندرويد.");
      return Promise.resolve(false);
    }
    return Printer.testPrint();
  };

  window.reconnectPrinter = function () {
    if (!Printer) return Promise.resolve(false);
    return Printer.reconnect();
  };

  /**
   * Small helper: build a `lines` array from your existing order object.
   * Adapt field names (order.items, order.total, etc.) to match your
   * actual data model — this is just a starting template.
   */
  window.buildReceiptFromOrder = function (order) {
    const lines = [
      { text: order.businessName || "المطعم", align: "center", bold: true },
      { text: new Date().toLocaleString("ar"), align: "center" },
      { text: "------------------------------", align: "center" },
    ];
    (order.items || []).forEach((item) => {
      lines.push({
        text: `${item.name}  x${item.qty}   ${item.price}`,
        align: "right",
      });
    });
    lines.push({ text: "------------------------------", align: "center" });
    lines.push({ text: `الإجمالي: ${order.total}`, align: "right", bold: true });
    return { lines, qrText: order.orderNumber ? String(order.orderNumber) : "" };
  };
})();
