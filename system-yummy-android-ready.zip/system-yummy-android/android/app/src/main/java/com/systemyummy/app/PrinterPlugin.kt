package com.systemyummy.app

import android.graphics.*
import android.net.*
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.Base64
import android.util.Log
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean

/**
 * PrinterPlugin
 * -------------
 * طابعة شبكة (Wi-Fi / TCP) عبر بروتوكول ESC/POS.
 * الطابعة: "Printer-AP_7694"  —  192.168.123.100:9100
 *
 * هذه النسخة لا "تصنع" الإيصال داخل Kotlin: كل تصميم الإيصال (بما فيه دعم
 * العربية RTL والـQR) مبني بالفعل داخل الصفحة نفسها عبر Canvas
 * (renderReceiptCanvas / canvasToRasterCommands في وحدة BTPrinter)، وهذا هو
 * نفس الكود الذي يبني بيانات الطلب الحقيقية من posCartItems/orderPayload —
 * فلا داعي لتكراره هنا أو افتراض حقول مختلفة. مهمة هذا الملف فقط:
 *   1) الاتصال بشبكة الطابعة (Wi-Fi) تلقائياً وإعادة الاتصال عند الانقطاع.
 *   2) إرسال أي بايتات ESC/POS خام تصلها من الواجهة عبر TCP بالترتيب (طابور).
 *   3) توفير صفحة اختبار طباعة أصلية (لا تعتمد على الواجهة) للتأكد من أن
 *      الاتصال بالعتاد نفسه سليم.
 *
 * Exposed to JS as: window.Capacitor.Plugins.PrinterPlugin
 *
 * Public methods called from JS:
 *   - getStatus()             -> { status: "connected" | "connecting" | "disconnected" }
 *   - printRaw({ bytes })     -> bytes = Base64 لأوامر ESC/POS كاملة جاهزة، تُطبع كما هي
 *   - testPrint()             -> يطبع صفحة اختبار أصلية (SP300W / IP:Port / Connection OK)
 *   - reconnect()             -> يجبر محاولة اتصال فورية بدل انتظار دورة إعادة المحاولة
 *
 * Events emitted to JS (via notifyListeners):
 *   - "printerStatusChanged" -> { status }
 */
@CapacitorPlugin(
    name = "PrinterPlugin",
    permissions = [
        Permission(strings = ["android.permission.ACCESS_FINE_LOCATION"], alias = "location"),
        Permission(strings = ["android.permission.ACCESS_WIFI_STATE"], alias = "wifiState"),
        Permission(strings = ["android.permission.CHANGE_WIFI_STATE"], alias = "wifiChange")
    ]
)
class PrinterPlugin : Plugin() {

    companion object {
        private const val TAG = "PrinterPlugin"

        // ===== إعدادات الطابعة المركزية (كما وردت في المتطلبات) =====
        const val SSID = "Printer-AP_7694"
        const val IP = "192.168.123.100"
        const val PORT = 9100
        const val PRINT_WIDTH_DOTS = 384 // نفس RASTER_WIDTH المستخدم في canvasToRasterCommands بالواجهة
        const val CONNECT_WAIT_TIMEOUT_MS = 8000L // أقصى انتظار لجاهزية الاتصال قبل تجاهل مهمة الطباعة
        const val RETRY_DELAY_MS = 4000L
    }

    private var connectivityManager: ConnectivityManager? = null
    private var wifiNetwork: Network? = null
    private val isConnecting = AtomicBoolean(false)
    @Volatile private var currentStatus = "disconnected"

    // كل عنصر في الطابور إما بايتات خام جاهزة (من الواجهة) أو علامة "طباعة اختبار أصلية"
    private data class PrintJob(val rawBytes: ByteArray?, val isNativeTest: Boolean)

    private val printQueue = LinkedBlockingQueue<PrintJob>()
    private var workerRunning = false

    override fun load() {
        connectivityManager =
            context.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        startWorkerThread()
        connectToPrinterNetwork()
    }

    // ================= الدوال المُستدعاة من JS =================

    @PluginMethod
    fun getStatus(call: PluginCall) {
        val ret = JSObject()
        ret.put("status", currentStatus)
        call.resolve(ret)
    }

    @PluginMethod
    fun reconnect(call: PluginCall) {
        connectToPrinterNetwork()
        call.resolve()
    }

    /**
     * bytes: نص Base64 لمصفوفة بايتات ESC/POS كاملة (تهيئة + صورة الإيصال + قص)
     * جاهزة تماماً من الواجهة (canvasToRasterCommands) — تُرسل كما هي دون أي تعديل.
     */
    @PluginMethod
    fun printRaw(call: PluginCall) {
        val b64 = call.getString("bytes")
        if (b64.isNullOrEmpty()) {
            call.reject("لا توجد بيانات طباعة (bytes) في الطلب")
            return
        }
        try {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            printQueue.offer(PrintJob(rawBytes = bytes, isNativeTest = false))
            call.resolve()
        } catch (e: Exception) {
            Log.e(TAG, "printRaw decode failed", e)
            call.reject("تعذّر فك ترميز بيانات الطباعة: " + e.message)
        }
    }

    /** طباعة اختبار أصلية (لا تعتمد على الواجهة) — للتحقق من الاتصال بالعتاد فقط. */
    @PluginMethod
    fun testPrint(call: PluginCall) {
        printQueue.offer(PrintJob(rawBytes = null, isNativeTest = true))
        call.resolve()
    }

    // ================= الاتصال بشبكة Wi-Fi الخاصة بالطابعة (أندرويد 10+) =================
    // على أندرويد 10 فما فوق لا يمكن للتطبيقات الانضمام لشبكة Wi-Fi بشكل صامت وعام؛ الطريقة
    // الرسمية المعتمدة من غوغل للوصول لجهاز محلي عبر واي فاي هي WifiNetworkSpecifier +
    // ConnectivityManager.requestNetwork. هذا يربط حركة بيانات هذا التطبيق فقط بشبكة الطابعة
    // دون تغيير شبكة الواي فاي الافتراضية للجهاز، وبدون نافذة تأكيد نظام متكررة (تظهر مرة واحدة فقط).

    private fun connectToPrinterNetwork() {
        if (isConnecting.get()) return
        isConnecting.set(true)
        setStatus("connecting")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val specifier = WifiNetworkSpecifier.Builder()
                .setSsid(SSID)
                .build()

            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(specifier)
                .build()

            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    Log.i(TAG, "Printer Wi-Fi network available")
                    wifiNetwork = network
                    connectivityManager?.bindProcessToNetwork(network)
                    isConnecting.set(false)
                    setStatus("connected")
                }

                override fun onUnavailable() {
                    Log.w(TAG, "Printer Wi-Fi network unavailable, will retry")
                    isConnecting.set(false)
                    setStatus("disconnected")
                    scheduleRetry()
                }

                override fun onLost(network: Network) {
                    Log.w(TAG, "Printer Wi-Fi network lost")
                    wifiNetwork = null
                    setStatus("disconnected")
                    scheduleRetry()
                }
            }
            connectivityManager?.requestNetwork(request, callback)
        } else {
            // مسار احتياطي لأندرويد أقدم من 10 (WifiManager.addNetwork/enableNetwork)
            try {
                val wifiManager =
                    context.applicationContext.getSystemService(android.content.Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val config = android.net.wifi.WifiConfiguration()
                config.SSID = "\"$SSID\""
                config.allowedKeyManagement.set(android.net.wifi.WifiConfiguration.KeyMgmt.NONE)
                @Suppress("DEPRECATION")
                val netId = wifiManager.addNetwork(config)
                @Suppress("DEPRECATION")
                wifiManager.enableNetwork(netId, true)
                isConnecting.set(false)
                setStatus("connected")
            } catch (e: Exception) {
                Log.e(TAG, "Legacy Wi-Fi connect failed", e)
                isConnecting.set(false)
                setStatus("disconnected")
                scheduleRetry()
            }
        }
    }

    private fun scheduleRetry() {
        Thread {
            Thread.sleep(RETRY_DELAY_MS)
            connectToPrinterNetwork()
        }.start()
    }

    private fun setStatus(status: String) {
        currentStatus = status
        val data = JSObject()
        data.put("status", status)
        notifyListeners("printerStatusChanged", data)
    }

    // ================= طابور الطباعة (Thread واحد فقط => لا تداخل إيصالات) =================

    private fun startWorkerThread() {
        if (workerRunning) return
        workerRunning = true
        Thread {
            while (workerRunning) {
                try {
                    val job = printQueue.take() // ينتظر حتى تصل مهمة
                    processJob(job)
                } catch (e: InterruptedException) {
                    // تجاهل، الحلقة تستمر
                } catch (e: Exception) {
                    Log.e(TAG, "Print job failed", e)
                }
            }
        }.start()
    }

    private fun processJob(job: PrintJob) {
        // ننتظر قليلاً إذا كنا وسط إعادة اتصال، لكن لا ننتظر إلى الأبد
        var waited = 0L
        while (currentStatus != "connected" && waited < CONNECT_WAIT_TIMEOUT_MS) {
            Thread.sleep(250)
            waited += 250
        }
        if (currentStatus != "connected") {
            Log.w(TAG, "Skipping print job, printer not connected")
            return
        }

        val bytes = if (job.isNativeTest) buildNativeTestPagePayload() else job.rawBytes
        if (bytes == null) return

        var socket: Socket? = null
        try {
            socket = Socket()
            socket.connect(InetSocketAddress(IP, PORT), 5000)
            val out: OutputStream = socket.getOutputStream()
            out.write(bytes)
            out.flush()
        } catch (e: Exception) {
            Log.e(TAG, "TCP print send failed", e)
            setStatus("disconnected")
            connectToPrinterNetwork()
        } finally {
            try { socket?.close() } catch (_: Exception) {}
        }
    }

    // ================= صفحة الاختبار الأصلية (ESC/POS مباشرة) =================

    private fun escInit() = byteArrayOf(0x1B, 0x40) // ESC @ تهيئة
    private fun escCut() = byteArrayOf(0x1D, 0x56, 0x00) // GS V 0 قص كامل
    private fun escFeed(lines: Int) = byteArrayOf(0x1B, 0x64, lines.toByte()) // ESC d n

    private fun buildNativeTestPagePayload(): ByteArray {
        val lines = listOf(
            "SP300W",
            "ESC/POS",
            "Wi-Fi",
            "$IP:$PORT",
            "Connection OK"
        )
        val bitmap = renderCenteredTextLines(lines)
        val out = ByteArrayOutputStream()
        out.write(escInit())
        out.write(bitmapToEscPosRaster(bitmap))
        out.write(escFeed(3))
        out.write(escCut())
        return out.toByteArray()
    }

    private fun renderCenteredTextLines(lines: List<String>): Bitmap {
        val width = PRINT_WIDTH_DOTS
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        paint.textSize = 26f
        paint.color = Color.BLACK

        var totalHeight = 16
        val layouts = mutableListOf<StaticLayout>()
        for (text in lines) {
            val layout = buildStaticLayout(text, paint, width)
            layouts.add(layout)
            totalHeight += layout.height + 8
        }

        val bitmap = Bitmap.createBitmap(width, totalHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        var y = 12f
        for (layout in layouts) {
            canvas.save()
            val dx = (width - layout.width) / 2f
            canvas.translate(dx, y)
            layout.draw(canvas)
            canvas.restore()
            y += layout.height + 8
        }
        return bitmap
    }

    private fun buildStaticLayout(text: String, paint: TextPaint, width: Int): StaticLayout {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setIncludePad(false)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(text, paint, width, Layout.Alignment.ALIGN_CENTER, 1f, 0f, false)
        }
    }

    /** يحوّل Bitmap أبيض/أسود إلى أوامر ESC/POS "GS v 0" لصورة راستر. */
    private fun bitmapToEscPosRaster(bitmap: Bitmap): ByteArray {
        val width = bitmap.width
        val height = bitmap.height
        val bytesPerRow = (width + 7) / 8
        val out = ByteArrayOutputStream()

        out.write(byteArrayOf(0x1D, 0x76, 0x30, 0x00)) // GS v 0, mode 0 (عادي)
        out.write(byteArrayOf((bytesPerRow and 0xFF).toByte(), ((bytesPerRow shr 8) and 0xFF).toByte()))
        out.write(byteArrayOf((height and 0xFF).toByte(), ((height shr 8) and 0xFF).toByte()))

        val rowBuffer = ByteArray(bytesPerRow)
        for (y in 0 until height) {
            rowBuffer.fill(0)
            for (x in 0 until width) {
                val pixel = bitmap.getPixel(x, y)
                val luminance = (Color.red(pixel) + Color.green(pixel) + Color.blue(pixel)) / 3
                val isBlack = luminance < 160 // عتبة بسيطة؛ عدّلها حسب نتيجة الطباعة الفعلية إذا لزم
                if (isBlack) {
                    rowBuffer[x / 8] = (rowBuffer[x / 8].toInt() or (0x80 shr (x % 8))).toByte()
                }
            }
            out.write(rowBuffer)
        }
        return out.toByteArray()
    }
}
