package com.systemyummy.app

import android.graphics.*
import android.net.*
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.Log
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import org.json.JSONArray
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean

/**
 * PrinterPlugin
 * -------------
 * Handles everything printer-related for the SP300W (ESC/POS over Wi-Fi/TCP).
 * Exposed to JS as: window.Capacitor.Plugins.PrinterPlugin
 *
 * Public methods called from JS:
 *   - getStatus()          -> { status: "connected" | "connecting" | "disconnected" }
 *   - printReceipt(data)   -> queues a receipt for printing
 *   - testPrint()          -> queues the built-in test page
 *   - reconnect()          -> forces a reconnect attempt
 *
 * Events emitted to JS (via notifyListeners):
 *   - "printerStatusChanged" -> { status }
 */
@CapacitorPlugin(
    name = "PrinterPlugin",
    permissions = [
        Permission(strings = ["android.permission.ACCESS_FINE_LOCATION"], alias = "location"),
        Permission(strings = ["android.permission.ACCESS_WIFI_STATE"], alias = "wifiState"),
        Permission(strings = ["android.permission.CHANGE_WIFI_STATE"], alias = "wifiChange")
    ]
)
class PrinterPlugin : Plugin() {

    companion object {
        private const val TAG = "PrinterPlugin"

        // ===== Central printer configuration (defaults from PRINTER SETTINGS spec) =====
        // NOTE: kept as vars (not vals) so an admin screen could change them later
        // and persist them via SharedPreferences if ever needed.
        var SSID = "Printer-AP_7694"
        var IP = "192.168.123.100"
        var PORT = 9100
        const val PRINT_WIDTH_DOTS = 576 // 80mm head, 203dpi -> 576 dots wide (72mm printable)
    }

    private var connectivityManager: ConnectivityManager? = null
    private var wifiNetwork: Network? = null
    private val isConnecting = AtomicBoolean(false)
    private var currentStatus = "disconnected"

    private val printQueue = LinkedBlockingQueue<JSObject>()
    private var workerRunning = false

    override fun load() {
        connectivityManager =
            context.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        startWorkerThread()
        connectToPrinterNetwork()
    }

    // ================= JS-facing methods =================

    @PluginMethod
    fun getStatus(call: PluginCall) {
        val ret = JSObject()
        ret.put("status", currentStatus)
        call.resolve(ret)
    }

    @PluginMethod
    fun reconnect(call: PluginCall) {
        connectToPrinterNetwork()
        call.resolve()
    }

    @PluginMethod
    fun printReceipt(call: PluginCall) {
        val data = call.data
        printQueue.offer(data)
        call.resolve()
    }

    @PluginMethod
    fun testPrint(call: PluginCall) {
        val data = JSObject()
        data.put("isTestPrint", true)
        printQueue.offer(data)
        call.resolve()
    }

    // ================= Wi-Fi connection (Android 10+ correct approach) =================
    // On Android 10+ apps can no longer silently toggle/join Wi-Fi networks system-wide.
    // The correct, Google-sanctioned way to reach a local Wi-Fi device (like this printer)
    // is WifiNetworkSpecifier + ConnectivityManager.requestNetwork. This binds ONLY this
    // app's printer traffic to the printer's network, without requiring the phone to
    // switch its default Wi-Fi network, and without a system "connect?" dialog every time
    // once the user has approved it once (Android may show a one-time system prompt the
    // very first time, which is an OS requirement we cannot bypass).

    private fun connectToPrinterNetwork() {
        if (isConnecting.get()) return
        isConnecting.set(true)
        setStatus("connecting")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val specifier = WifiNetworkSpecifier.Builder()
                .setSsid(SSID)
                .build()

            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(specifier)
                .build()

            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    Log.i(TAG, "Printer Wi-Fi network available")
                    wifiNetwork = network
                    connectivityManager?.bindProcessToNetwork(network)
                    isConnecting.set(false)
                    setStatus("connected")
                }

                override fun onUnavailable() {
                    Log.w(TAG, "Printer Wi-Fi network unavailable, will retry")
                    isConnecting.set(false)
                    setStatus("disconnected")
                    scheduleRetry()
                }

                override fun onLost(network: Network) {
                    Log.w(TAG, "Printer Wi-Fi network lost")
                    wifiNetwork = null
                    setStatus("disconnected")
                    scheduleRetry()
                }
            }
            connectivityManager?.requestNetwork(request, callback)
        } else {
            // Legacy path for Android < 10 (WifiManager.addNetwork/enableNetwork).
            // Kept minimal since target devices are typically modern; expand only if needed.
            try {
                val wifiManager =
                    context.applicationContext.getSystemService(android.content.Context.WIFI_SERVICE) as WifiManager
                val config = android.net.wifi.WifiConfiguration()
                config.SSID = "\"$SSID\""
                config.allowedKeyManagement.set(android.net.wifi.WifiConfiguration.KeyMgmt.NONE)
                val netId = wifiManager.addNetwork(config)
                wifiManager.enableNetwork(netId, true)
                isConnecting.set(false)
                setStatus("connected")
            } catch (e: Exception) {
                Log.e(TAG, "Legacy Wi-Fi connect failed", e)
                isConnecting.set(false)
                setStatus("disconnected")
                scheduleRetry()
            }
        }
    }

    private fun scheduleRetry() {
        Thread {
            Thread.sleep(4000)
            connectToPrinterNetwork()
        }.start()
    }

    private fun setStatus(status: String) {
        currentStatus = status
        val data = JSObject()
        data.put("status", status)
        notifyListeners("printerStatusChanged", data)
    }

    // ================= Print worker (single-threaded queue => no job overlap) =================

    private fun startWorkerThread() {
        if (workerRunning) return
        workerRunning = true
        Thread {
            while (workerRunning) {
                try {
                    val job = printQueue.take() // blocks until a job exists
                    processJob(job)
                } catch (e: InterruptedException) {
                    // ignore, loop continues
                } catch (e: Exception) {
                    Log.e(TAG, "Print job failed", e)
                }
            }
        }.start()
    }

    private fun processJob(job: JSObject) {
        // Wait briefly for a connection if we're mid-reconnect, but never block forever.
        var waited = 0
        while (currentStatus != "connected" && waited < 8000) {
            Thread.sleep(250)
            waited += 250
        }
        if (currentStatus != "connected") {
            Log.w(TAG, "Skipping print job, printer not connected")
            return
        }

        val bytes = if (job.optBoolean("isTestPrint", false)) {
            buildTestPagePayload()
        } else {
            buildReceiptPayload(job)
        }

        var socket: Socket? = null
        try {
            socket = Socket()
            socket.connect(java.net.InetSocketAddress(IP, PORT), 5000)
            val out: OutputStream = socket.getOutputStream()
            out.write(bytes)
            out.flush()
        } catch (e: Exception) {
            Log.e(TAG, "TCP print send failed", e)
            setStatus("disconnected")
            connectToPrinterNetwork()
        } finally {
            try { socket?.close() } catch (_: Exception) {}
        }
    }

    // ================= ESC/POS payload builders =================

    private fun escInit() = byteArrayOf(0x1B, 0x40) // ESC @ initialize
    private fun escCut() = byteArrayOf(0x1D, 0x56, 0x00) // GS V 0 full cut
    private fun escFeed(lines: Int) = byteArrayOf(0x1B, 0x64, lines.toByte()) // ESC d n

    private fun buildTestPagePayload(): ByteArray {
        val lines = listOf(
            "SP300W",
            "ESC/POS",
            "Wi-Fi",
            "$IP:$PORT",
            "Connection OK"
        )
        val bitmap = renderTextLines(lines, centered = true)
        val out = ByteArrayOutputStream()
        out.write(escInit())
        out.write(bitmapToEscPosRaster(bitmap))
        out.write(escFeed(3))
        out.write(escCut())
        return out.toByteArray()
    }

    /**
     * Renders the ENTIRE receipt (Arabic + French/Latin, bold, alignment, sizes)
     * as one bitmap using Android's native text layout engine, which already
     * handles Arabic shaping and RTL direction correctly. This bitmap is then
     * sent as a raster image via ESC/POS (GS v 0), which sidesteps the
     * unreliable Arabic code-page problem entirely — this is the fallback
     * strategy called out explicitly in the requirements, used here as the
     * primary path for maximum reliability.
     */
    private fun buildReceiptPayload(job: JSObject): ByteArray {
        val bitmap = renderReceipt(job)
        val out = ByteArrayOutputStream()
        out.write(escInit())
        out.write(bitmapToEscPosRaster(bitmap))

        // Optional QR / barcode: if job includes qrText, print it as a native
        // ESC/POS QR block (crisper than a bitmap QR at small sizes).
        val qrText = job.optString("qrText", "")
        if (qrText.isNotEmpty()) {
            out.write(buildQrCommand(qrText))
        }

        out.write(escFeed(4))
        out.write(escCut())
        return out.toByteArray()
    }

    private fun renderReceipt(job: JSObject): Bitmap {
        val linesArray: JSONArray = job.optJSONArray("lines") ?: JSONArray()
        val textLines = mutableListOf<Triple<String, String, Boolean>>() // text, align, bold
        for (i in 0 until linesArray.length()) {
            val lineObj = linesArray.optJSONObject(i) ?: continue
            val text = lineObj.optString("text", "")
            val align = lineObj.optString("align", "right") // default right for Arabic-heavy receipts
            val bold = lineObj.optBoolean("bold", false)
            textLines.add(Triple(text, align, bold))
        }
        return renderStyledLines(textLines)
    }

    private fun renderTextLines(lines: List<String>, centered: Boolean): Bitmap {
        val styled = lines.map { Triple(it, if (centered) "center" else "left", false) }
        return renderStyledLines(styled)
    }

    private fun renderStyledLines(lines: List<Triple<String, String, Boolean>>): Bitmap {
        val width = PRINT_WIDTH_DOTS
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        paint.textSize = 28f
        paint.color = Color.BLACK

        // First pass: measure total height
        var totalHeight = 16
        val layouts = mutableListOf<StaticLayout>()
        for ((text, _, bold) in lines) {
            paint.isFakeBoldText = bold
            val layout = buildStaticLayout(text, paint, width)
            layouts.add(layout)
            totalHeight += layout.height + 6
        }

        val bitmap = Bitmap.createBitmap(width, totalHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        var y = 12f
        for ((index, triple) in lines.withIndex()) {
            val (_, align, _) = triple
            val layout = layouts[index]
            canvas.save()
            val dx = when (align) {
                "center" -> (width - layout.width) / 2f
                "left" -> 8f
                else -> (width - layout.width - 8f) // "right"
            }
            canvas.translate(dx, y)
            layout.draw(canvas)
            canvas.restore()
            y += layout.height + 6
        }
        return bitmap
    }

    private fun buildStaticLayout(text: String, paint: TextPaint, width: Int): StaticLayout {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setIncludePad(false)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(text, paint, width, Layout.Alignment.ALIGN_NORMAL, 1f, 0f, false)
        }
    }

    /** Converts a black/white bitmap into ESC/POS "GS v 0" raster image bytes. */
    private fun bitmapToEscPosRaster(bitmap: Bitmap): ByteArray {
        val width = bitmap.width
        val height = bitmap.height
        val bytesPerRow = (width + 7) / 8
        val out = ByteArrayOutputStream()

        out.write(byteArrayOf(0x1D, 0x76, 0x30, 0x00)) // GS v 0, mode 0 (normal)
        out.write(byteArrayOf((bytesPerRow and 0xFF).toByte(), ((bytesPerRow shr 8) and 0xFF).toByte()))
        out.write(byteArrayOf((height and 0xFF).toByte(), ((height shr 8) and 0xFF).toByte()))

        val rowBuffer = ByteArray(bytesPerRow)
        for (y in 0 until height) {
            rowBuffer.fill(0)
            for (x in 0 until width) {
                val pixel = bitmap.getPixel(x, y)
                val luminance = (Color.red(pixel) + Color.green(pixel) + Color.blue(pixel)) / 3
                val isBlack = luminance < 160 // simple threshold; swap for dithering if needed
                if (isBlack) {
                    rowBuffer[x / 8] = (rowBuffer[x / 8].toInt() or (0x80 shr (x % 8))).toByte()
                }
            }
            out.write(rowBuffer)
        }
        return out.toByteArray()
    }

    /** Native ESC/POS QR code block (model 2, medium error correction). */
    private fun buildQrCommand(data: String): ByteArray {
        val out = ByteArrayOutputStream()
        val bytes = data.toByteArray(Charsets.UTF_8)
        val storeLen = bytes.size + 3

        fun gsFunc108(fn: Int, vararg params: Int) {
            out.write(byteArrayOf(0x1D, 0x28, 0x6B, (params.size + 2).toByte(), 0x00, 0x31, fn.toByte()))
            for (p in params) out.write(p)
        }

        out.write(byteArrayOf(0x1D, 0x28, 0x6B, 0x04, 0x00, 0x31, 0x41, 0x32, 0x00)) // model 2
        out.write(byteArrayOf(0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x43, 0x06))       // module size 6
        out.write(byteArrayOf(0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x45, 0x31))       // EC level M
        out.write(byteArrayOf(0x1D, 0x28, 0x6B, (storeLen and 0xFF).toByte(), ((storeLen shr 8) and 0xFF).toByte(), 0x31, 0x50, 0x30))
        out.write(bytes)
        out.write(byteArrayOf(0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x51, 0x30)) // print
        return out.toByteArray()
    }
}
